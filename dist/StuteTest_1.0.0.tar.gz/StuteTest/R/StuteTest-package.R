## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

## usethis namespace: start
#' @useDynLib StuteTest, .registration = TRUE
## usethis namespace: end
NULL